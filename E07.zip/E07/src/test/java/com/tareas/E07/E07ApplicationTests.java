package com.tareas.E07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
