package com.tareas.E07;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E07Application {

	public static void main(String[] args) {
		SpringApplication.run(E07Application.class, args);
	}

}
