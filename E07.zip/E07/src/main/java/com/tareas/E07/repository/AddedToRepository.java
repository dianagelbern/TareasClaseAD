package com.tareas.E07.repository;

import com.tareas.E07.model.AddedTo;
import com.tareas.E07.model.AddedToPK;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddedToRepository extends JpaRepository<AddedTo, AddedToPK> {
}
