package com.ejercicio.E08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
