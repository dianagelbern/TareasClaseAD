package com.ejercicio.E08.repository;

import com.ejercicio.E08.model.ClienteIndividual;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteIndividualRepository extends JpaRepository<ClienteIndividual, Long> {
}
