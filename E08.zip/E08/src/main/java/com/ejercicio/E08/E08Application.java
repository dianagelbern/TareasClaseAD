package com.ejercicio.E08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E08Application {

	public static void main(String[] args) {
		SpringApplication.run(E08Application.class, args);
	}

}
